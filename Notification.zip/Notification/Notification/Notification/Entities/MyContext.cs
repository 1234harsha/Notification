﻿using Microsoft.EntityFrameworkCore;
using Notification.Model;
using System.Collections.Generic;

namespace Notification.Entities
{
    public class MyContext:DbContext
    {
        private readonly IConfiguration configuration;

        public MyContext(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        //define entity set
        public DbSet<NotificationEntity> notificationEntities { get; set; }
       
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //optionsBuilder.UseSqlServer(@"Data Source=INTERNS118\SQLEXPRESS;Initial Catalog=SMSDB;Integrated Security=True;Trust Server Certificate=True");
            optionsBuilder.UseSqlServer(configuration.GetConnectionString("MyConnection"));
        }
    }

}

