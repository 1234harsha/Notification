﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Notification.Model;
using Notification.Repository;

namespace Notification.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationController : ControllerBase
    {
        private readonly NotificationRepository notificationRepository;

        public NotificationController(NotificationRepository notificationRepository)
        {
            this.notificationRepository = notificationRepository;
        }

        [HttpPost, Route("AddNotification")]
        public IActionResult Add([FromBody] NotificationEntity notification)
        {
            notificationRepository.Add(notification);
            return Ok(notification);
        }
        [HttpPut, Route("EditNotification")]
        public IActionResult Update([FromBody] NotificationEntity notification)
        {
            notificationRepository.Update(notification);
            return Ok(notification);
        }
        [HttpGet, Route("GetNotification")]
        public IActionResult GetAll()
        {
            return Ok(notificationRepository.GetAll());
        }
        [HttpDelete, Route("DeleteNotification/{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                notificationRepository.Delete(id);
                return Ok("Notification Deleted");
            }
            catch (Exception)
            {
                throw;
            }
        }
      
    }
}
